const path = require('path')
const NodePolyfillPlugin = require("node-polyfill-webpack-plugin")
const webpack = require('webpack')

module.exports = {
   devtool:'source-map',
    mode : 'production',
   entry: './client/index.js', // Our frontend will be inside the src folder
   output: {
      path: path.resolve(__dirname, 'public'),
      filename: '[name].build.js', // The final file will be created in dist/build.js

      
   },
   
   plugins: [
      new NodePolyfillPlugin(),

   ],
   
   node: {
      global: true
    },
      devServer : {
    //contentBase: path.join(__dirname,'public'),
    static : {
      directory : path.join(__dirname, "public/")
    },
    compress: true,
    port:8083
   },
   resolve: {
      fallback: {
       /// http: require.resolve("stream-http"),
       /// https: require.resolve("https-browserify"),
        //crypto: require.resolve("crypto-browserify"),
        //stream: require.resolve("stream-browserify"),
        //os: require.resolve("os-browserify/browser"),
       // url: require.resolve("url"),
        //assert: require.resolve("assert"),
      }
   }
}